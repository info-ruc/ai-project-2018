import numpy as np
from sklearn.externals import joblib
from sklearn import svm
from sklearn.model_selection import GridSearchCV
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


def trainData(type,trD):
    #从csv文件中读取已提取好的特征，每个音频有一个csv文件，每一列为一帧的34个特征
    T = []
    label = []
    count = 0
    for i in type:  # type
        # print('compare with number ',i,' the distance is:')
        for j in trD:  # speeker 2 to 9
            print('number ',i,' speeker ',j)
            path = str(i) + '_' + str(j) + '.csv'
            file =open(path,'r')
            lines=file.readlines()
            file.close()
            row=[]#定义行数组
            for line in lines:
                row.append(line.split(','))
            for k in range(len(row[0])):
                column=[]#定义列数组
                count=count+1
                for col in row:  #选取何种特征在此处控制
                    column.append(col[k])
                label.append(i)
                if(count==1):
                    T=column
                else:
                    T=np.vstack((T,column))
    return T,label


def trainSVM(type,trD):  #SVM分类器
    print("Is training now……")
    T,label=trainData(type,trD)
    clf=svm.SVC(C=1,gamma=0.1,kernel='rbf')  #参数已调优
    clf.fit(T,label)
    save_path="modelSVM.m"
    joblib.dump(clf,save_path)

def findBestPara(type,trD):    #分类器参数调优
    T,label=trainData(type,trD)
    tuned_parameters = [{'kernel':['linear'],'C':[0.1,1,10]},
                        {'kernel':['rbf'],'C':[0.1,1,10],'gamma': [1,0.1,0.01]},
                        {'kernel':['poly'],'C':[0.1,1,10],'gamma': [1,0.1,0.01]}]
    grid = GridSearchCV(svm.SVC(), tuned_parameters, cv=4, verbose=2)
    # 用训练集训练这个学习器 clf
    grid.fit(T, label)
    print("Grid scores on development set:")
    print()
    means = grid.cv_results_['mean_test_score']
    stds = grid.cv_results_['std_test_score']
    # 看一下具体的参数间不同数值的组合后得到的分数是多少
    for mean, std, params in zip(means, stds, grid.cv_results_['params']):
        print("%0.3f (+/-%0.03f) for %r"
              % (mean, std * 2, params))
    print("\nThe best parameters are %s with a score of %0.2f" % (grid.best_params_, grid.best_score_))

def lowDimension(T,label):  #LDA降维
    lda = LinearDiscriminantAnalysis(n_components=13)
    lda.fit(T, label)
    T_new = lda.transform(T)
    return T_new

if __name__ == '__main__':
    type=[9,11,21,43,44]  #43:siren 9:sheep 11:rain 21:crying baby 44:car horn
    trD=range(2,10)   #train part 确定某种类型中用于训练的音频名称
    teD=range(0,2)   #test part 确定某种类型中用于测试的音频名称
    #trainSVM(type,trD)  #训练SVM模型
    #findBestPara(type,trD)  #寻找SVM最优参数

    test_size = 0  #测试数据个数，用于计算命中率
    hit = 0  #命中次数，用于计算命中率
    for t in type:  #对测试数据做遍历
        for s in teD:  #test data 对测试数据做遍历
            test_size+=1
            test=[]
            result=11   #随意初始化的一个result值
            test_path = str(t) + '_' + str(s) + '.csv'  #从csv中读取特征信息
            file = open(test_path, 'r')
            lines = file.readlines()
            file.close()
            row = []  # 定义行数组
            count=0
            for line in lines:
                row.append(line.split(','))
            for i in range(len(row[0])):
                column = []  # 定义列数组
                count = count + 1
                for col in row:
                    column.append(col[i])
                if (count == 1):
                    test = column
                else:
                    test = np.vstack((test, column))
            test = np.array(test, dtype=np.float)
            #print(test.shape)
            #一段测试音频数据读取完毕
    
            vote=np.zeros(51)  #每帧投一次票，统计用于预测
            model_path = "modelSVM.m"
            clf=joblib.load(model_path)
            for frameMFCC in test:
                P = clf.predict([frameMFCC])[0]
                vote[P]+=1
            result=np.argmax(vote)
            print('the number is:', t)
            print('the predict number is:', result)
            #计算命中率
            if result == t:
                hit = hit + 1
    hitrate = hit / test_size
    print('the hit rate is:', hitrate)
